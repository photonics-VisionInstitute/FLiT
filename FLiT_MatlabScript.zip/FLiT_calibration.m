%% script for initialize device anc defien main system parameters and implemnt the required calbiration (includign power control, single tile hologram efficiency etc. ) 

%% Configurate NI daq adn Arduino 

d = daq("ni");
addoutput(d, "Dev7", "ao0", "Voltage");
addoutput(d, "Dev7", "ao1", "Voltage");

clear ardUno
disp('Opening Arduino for electrophy triggering...')
ardUno = arduino('COM45'); 
%pinMode(ardUno,10,'output');
configurePin(ardUno,'D10','DigitalOutput');
writeDigitalPin(ardUno,'D10',0);

%% Parameters
% SLM parameters 
NlineonSLM=45; %30; 
%%% waveform AOM-galvo frequency 
rate = 1000000; %Hz

xstretch= 1.0407  *0.98;%1.15;/1.0412
ystretch=0.85 %0.95%0.96%.0407;%*1.02;%1.18;
zstretchUP = -1*0.91*1.36*0.779;  % the negqtive sign take into account the direction of te shift
zstretchDOWN=-1*0.81*1.36*0.779; 

theta=(0.5+3.20+0.5-90)/180*pi; %°

xOFFSET = 20; % horizontal in the camera   %negative towards left
yOFFSET = -1;  %vertical in the camera  % negqtive towards down
zOFFSET = 3;  %

%% AOM calibration laser power- SATSUMA POwER CONTROL  
calibAOM = [0,0.5,1,1.5,2,2.4,2.7,2.75,2.85,2.9,3,3.1,3.2,3.3,3.4,3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.4,5.7, 6, 6.4, 6.8, 7.2, 7.6, 8, 8.4,8.8, 9.5;...
   0,0,0,0,1,4,13,16,23,27,38,50,65,82,103,154,218,300,393,502,627,765,918,1250,1520,1790,2140,2460,2730,2940,3090,3180,3230,3248];
calibAOM(2,:)=calibAOM(2,:)*1000/3248; % 

x = calibAOM(1,:);
y = calibAOM(2,:);

power_fun =  @(coeff, x)  ( ((-log(1-(x-coeff(4))/coeff(1))).^(1/coeff(5)))*coeff(3)+coeff(2) );

x0=[-3221.53303311144,9.94648654271492,-3.81300273251089,3221.51004476745,0.5];

coeffvals=lsqcurvefit(power_fun,x0,y(5:end),x(5:end));

figure;plot(x,y,'x')
hold on
plot(power_fun(coeffvals,y),y)
xlabel('Voltage (mV)')
ylabel('Power (mW)')

%% Define Voltage and efficiency of each line on the SLM

LineGalvV =[ NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 169, 156.5, 144,  131.75,   119.5, 107, 94.5, 81.7, 68.9 , 55.95, 43, 30.5, 18, 5.4, -7.2, -19.6, -32, -45, -58, -70.5, -83, -95.75, -108.5, -121.25, -134, -146.25, -158.5, -171.25, -184, -196.5, -209, ]/1000-0.002;

powerLine = [4.57,4.57,4.57,4.57,4.57,4.57,4.57,4.57,4.57,4.57, 4.57490000000000,26.8198000000000,49.0647000000000,72.4768000000000,95.8889000000000,119.013900000000,142.138900000000,174.273550000000,206.408200000000,234.754150000000,263.100100000000,276.483250000000,289.866400000000,305.829900000000,321.793400000000,308.115850000000,294.438300000000,284.070450000000,273.702600000000,259.363550000000,245.024500000000,205.895200000000,166.765900000000,145.959050000000,125.152200000000,103.532650000000,81.9131000000000,45.6667500000000,9.42040000000000, 9.42,9.42,9.42,9.42,9.42,9.42]

idx = 1:1:NlineonSLM;
xline = 1:1:NlineonSLM;

figure;
yyaxis left
plot(xline(idx),LineGalvV(idx),'x')
xlabel('line #'); ylabel('galv cmd (V)');xlim([1 NlineonSLM])
yyaxis right
plot(xline(idx),powerLine(idx),'x')
xlabel('line #');ylabel('intensity');xlim([1 NlineonSLM])

LinePowerV = 1*ones(size(LineGalvV));

% final adjustment 04/06
%CorrPowerV =[1.92724822331886,1.92724822331886,1.92724822331886,1.51686682202236,1.92724822331886,1.47813191210387,1.53741222957161,1.03226632730696,0.980000000000000,1.07205798972506,1.03652311372649,1.11836089543446,1.17600115790940,1.15173372184622,1.13171912475663,1.16027964212351,1.32966161108757,1.53704003314555,1.80165356146945,1.92724822331886]';

% after16/06/2021 new slm 30 lines
CorrPowerV =sqrt(1./(powerLine/max(powerLine)));
 figure;yyaxis left;plot(CorrPowerV,'HandleVisibility','off');ylabel('correction factor');yyaxis right;hold on;plot(powerLine);ylabel('intensity')

%%  calibration for extraction of line intensities 
nNlineCalib=45;
clear SpotListCalib
SpotListCalib(1,:)=[1:2:nNlineCalib];
for i=numel(SpotListCalib(1,:))
    SpotListCalib(2,:)=20;
    SpotListCalib(3,:)=-20;
    SpotListCalib(4,:)=0;
    SpotListCalib(5,:)=0.99;
end
SpotList = SpotListCalib;
savefilename = 'spotlist.mat';
save([fullpath savefilename],'SpotList')

%% Calibration /alignement section 1 : place galvo on a given Line sending the correspondign voltage
lineIND=25
galvoV=LineGalvV(lineIND);
aomV=2.85; % V
write(d,[galvoV,aomV]);

%%
%% generate spot on a grid 
[Xtnew,Ytnew,Xt0new,Yt0new] =  grid_random_offset(4,4,65,65,0.15);  % 16 spot 

r=[1:1:numel(Xtnew(:))];
mat=[Xtnew(r)',Ytnew(r)'];
blobpos=mat+[20,-15]; %shift 
blobpos=mat+[0,0]; %shift 
N = size(mat,1);  
figure;
for i=1:N
    scatter( blobpos(i,1),blobpos(i,2))
    text(blobpos(i,1),blobpos(i,2) ,num2str(i))
    hold on
end
title([ 'sequence of ' , num2str(N) ' spot'])

%% DE correction
%create the calibration grid used for extraning postion depndent spot
%intensity due to diffraction effciency

[Xt,Yt,Xt0,Yt0] =  grid_random_offset(6,6,70,70,0.05);  %test

lines = 25;% 15:1:20;
Ndistrib = 5;

spotlist = distrib_line_random(Xt,Yt,lines);
spotlist3D = zeros([size(spotlist) Ndistrib]);
Z = zeros(1,size(spotlist,2));
W = 100*ones(1,size(spotlist,2));
for i =1:Ndistrib
    spotlist = distrib_line_random(Xt,Yt,lines);
    % save spot list
    SpotList = [spotlist;Z;W];
    filename = ['spotlistcalib' num2str(i) '.mat'];
    save([folder_path filename],'SpotList')
    spotlist3D(:,:,i) = spotlist;
end

%% calibration of Diffraction efficiency

[Xt,Yt,Xt0,Yt0] = grid_random_offset(6,6,68,68,0.00); % I used this since 25/10/21

%the order is from bottom left corner going up 
grid275 = [553, 936,1079,1082,593,400; 634,1187,1308,1532,1125,475;906,1089,1500,1320,708,643;984,1533,1176,1377,880,545;851,1507,1439,1456,929,446;495,816,993,936,530,400];
[Xt,Yt,Xt0,Yt0] = grid_random_offset(6,6,70,70,0.00); % I used this since 25/10/21

grid275DE2 = [134,734,844,697,129,90; 553,568,1092,1089,567,87;858,1419,1444,1191,697,324;806,1588,1701,1462,872,147;583,1374,1424,926,409,90;23,150,381,179,110,90];  % 01/11/2022

step=70;
grid275 = grid275./max(grid275(:));
XY275 = -275/2:step:275/2;

grid275 = grid275./max(grid275(:));

V = grid275;
V = sqrt(V);
V = flipud((V));

grid275DE = grid275DE./max(grid275DE(:));
grid275DE2 = grid275DE2./max(grid275DE2(:));

figure;
subplot(2,1,1)
imagesc(grid275)
colorbar
c = caxis;
title(['std = ' num2str(std(grid275(:)),3)])
subplot(2,1,2)
imagesc(grid275DE2)
colorbar
caxis(c);
title(['+ DE corr ; std = ' num2str(std(grid275DE2(:)),3)])

figure; imagesc(V); colorbar
title(['Intensity map'])

