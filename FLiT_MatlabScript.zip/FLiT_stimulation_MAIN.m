%%% Here we defien the EXPERIMENT PIPELINE , the stimuatlion parameter and
%%% we perform a FliT cyclic stimualtion of a group of cells whose
%%% coordinates are improted from an external file  

% parameters and calibration define in the EXPcalib.m script are used 


%% define ROI in imageJ first ; run the macro and and then import file from ImageJ 
% this section acquire spot are defined as ROI in imageJ and exported as
% csv file 
pathref=[' ']
[filetemp,pathtemp]=uigetfile('*.csv','Select a csv file;;;',pathref)% path, '*.tif');
nam = fullfile(pathtemp,filetemp);

%%%%% to set manually  for every stack !!!!!! 
Nslice =1;
Zcenter = round(Nslice/2);
zstep =0*(-1); %if 3D 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tempdt=importdata(nam);
if size(tempdt.data(1,:),2)==9;
    blobpospix=tempdt.data(:,[4:5,7]);
else blobpospix=tempdt.data(:,[4:6]); end
blobpospix(:,2)=-blobpospix(:,2)+256;

% to shuffle randomly spot between lines
shuffleON = 1;
if shuffleON
    blobpospix = blobpospix(randperm(size(blobpospix,1)),:);   
end

  
%%%%%%%%%%%%%%%%%%%%%%%%%%
blobpos = [(blobpospix(:,1) - XYcenter(1))*pixSize ...
    (blobpospix(:,2) - XYcenter(2))*pixSize ...
    (blobpospix(:,3) -Zcenter) *zstep]; %um

%%%%%%%%%%%%%%%%%%%%%%%%%% 
N = size(blobpos,1);
Nspot=N;

figure;
subplot(1,2,1)
for i=1:N
    scatter( blobpos(i,1),blobpos(i,2))
    text(blobpos(i,1),blobpos(i,2) ,num2str(i))
    hold on
end
title([ 'sequence of ' , num2str(N) ' spot'])
subplot(1,2,2)
for i=1:N
    scatter3( blobpos(i,1),blobpos(i,2),blobpos(i,3))
    %text(blobpos(i,1),blobpos(i,2) ,num2str(i))
    hold on
end

%% % load rois FROM BLOBPOS file and divide them onto lines
%fullpath = 'E:\experimental\FastSwitch\Optics\15062021\';
fullpath = 'Y:\PhaseMAsk_shared\';
loadfile = 'blobPos.txt';
mat = loadrois([fullpath ],1);
blobpos=mat; 
N = size(mat,1); 
 
%% plot all spot inside the blobpos variable
figure;
for i=1:N
    scatter( blobpos(i,1),blobpos(i,2))
    text(blobpos(i,1),blobpos(i,2) ,num2str(i))
    hold on
end
title([ 'sequence of ' , num2str(N) ' spot'])

%%

%% distribute spot  between lines holoorams   - 
% Her we save  two spotlist variable containing the vision of spto between line - 
% the two spotlist corrsiponds to the condition in which all the spot are adress into a signle hologram or divded 
% among multiple lines  
% the spotList file can then be used as input to any algorithm chosen to
% calculate each holograms and then adress the SLM phasemask accordingly 

clear SpotList X Y Z Ztemp L L0 corrDXZ

Nline =12;  %    # lines to use
LineTOuse = 25;  % lines to use in case of using a single line

% XY 
Nspot=size(blobpos,1);

q = floor(Nspot/Nline);
r = Nspot - q*Nline;
offsetLine=0; 

if r == 0
    L = repmat(1:1:Nline,[1 q]) + round((NlineonSLM - Nline)/2) +offsetLine;
else
    L1 = repmat(1:1:r,[q+1 1]) + round((NlineonSLM - Nline)/2)+offsetLine;
    L2 = repmat(r+1:Nline,[q 1]) + round((NlineonSLM - Nline)/2)+offsetLine;
    L = [L1(:);L2(:)]';
end


if size(blobpos,2) == 2     % if blobpos is only [X,Y], add a column Z = 0
   blobpos = [blobpos zeros(size(blobpos,1),1)]; 
end


% to shuffle randomly spot between lines
shuffleON =1;
if shuffleON
    blobpos = blobpos(randperm(size(blobpos,1)),:);   
end


% %% BASIC SPATIAL CALIBRATION 
% Here we  introduce an offset a stretch and x-y rotation on the spot
% coordinates 
xstretch=1.0;
ystretch=1.1;
zstretchUP =1; % stretch for positive z values 
zstretchDOWN=1; % stretch for negative z values 

xOFFSET =3;
yOFFSET =5;

zOFFSET = 0;  %
theta=(4.20-1.5-90)/180*pi; % 


blobposTEMP=blobpos;
Xtemp = blobposTEMP(:,1)'*xstretch; 
Ytemp = blobposTEMP(:,2)'*ystretch; 

% HEre we apply ther coordiante trasformation The final coordinate becomes X,Y,Z
X=(Xtemp+xOFFSET)*cos(theta)-(Ytemp+yOFFSET)*sin(theta);
Y=(Xtemp+xOFFSET)*sin(theta)+(Ytemp+yOFFSET)*cos(theta);
Z = Ztemp +zOFFSET;

% here define weight 
W = zeros(size(X));
WsingleLine = zeros(size(X));

%V=ones(size(V));     %uncomment to not include any diff. Eff. correction 

%% HERE correction of vertical shift of spots (X coordinate) at different  lines
% verified by sending the same spot over each line  

central_line =23;
mx=0.2;
Dx=@(L) (L-central_line)*mx ;

%% HERE correction of vertical shift of spots (X coordinate) at different  lines

corrZ=ones(length(Z),1)';

Zcalib = [-420 -200 -80 -40 0 30 50 80 115 200];

F= [836 1247 1326 1271 1130 948 827 684 540 450]-212;
I = sqrt(F);
I = I/max(I);
DEz=@(Z) interp1(Zcalib,I,Z);
corrZ=1./DEz(Z);

% Diffraction Efficiency correction
PowerCorrDE = zeros(1,NlineonSLM);
%additional exponent  coeeficient to elevate the V matrix
corrEXPV=1;%0.8;
for i = 1:Nline
    idxL = L(1)+i-1;
    blobposTEMP = [X(L==idxL);Y(L==idxL)]';
    [powers,~,corr_weights] = power_corr2(1,[1:1:size(blobposTEMP,1)],blobposTEMP,Xt0,Yt0,V,[]); 
    idx = find(L == idxL);
    for j = 1:length(idx)
        W(idx(j)) = corr_weights(j)*corrZ(idx(j));   % include slight correctio DE z
    end
    PowerCorrDE(idxL) = powers*sum(corrZ(idx))/length(idx);   % include slight correctio DE z
end
W=W/max(W)*0.9999;

    % DE sor singleLine
LsingleLine = repmat(LineTOuse,size(X));

PowerCorrDEsingleLine = zeros(1,NlineonSLM);

blobposTEMP2 = [X;Y]';
[powers,corr_spot_diameters,corr_weights] = power_corr2(1,[1:1:size(blobposTEMP2,1)],blobposTEMP2,Xt0,Yt0,V.^corrEXPV,[]);
for j = 1:length(corr_weights)
    WsingleLine(j) = corr_weights(j);
end

%WsingleLine = ones(size(WsingleLine)); % remove DE corr
PowerCorrDEsingleLine(LineTOuse) = powers*sum(corrZ)/Nspot;  %%% ATTENTION  correctio for DEz 
  WsingleLine=  WsingleLine.*corrZ;    %%% ATTENTION  correctio for DEz 
  WsingleLine=  WsingleLine/max(WsingleLine)-0.001


% correction for off focus X and Y shift of spots in both the central and peripherl line  

L0=25; %central line correspondign to no tilt on x direction 

z0=80;

shiftPERlineX=4.16; 
shiftPERlineY=15; % 
DxT=@(Z,L) Z/z0.*(L0-L)*shiftPERlineX; 
DyT=@(Z) Z/z0*(shiftPERlineY); 

% I define the shift vector for multi line case 
for i=1:Nspot;
    corrDXZ(i)=DxT(blobpos(i,3),L(i));   % the calcualtion is done on the nomila values so Ztemp, that is blobpos(i,3)
end

SpotListAllLines = [L;-X+(Dx(L)+corrDXZ);Y+DyT(Z);Z;W*100];

SpotListsingleLine = [LsingleLine;-X+(Dx(LsingleLine))+DxT(Z,LsingleLine);Y+DyT(Z);Z;WsingleLine*100];

% pathTOpython=('G:\experimental\FastSwitch\optics\scripts\phyton\')
 xtopython=-X+(Dx(LsingleLine))+DxT(Z,LsingleLine);
 ytopython= Y+DyT(Z);
 weightstopython=WsingleLine;
% 
 save ([pathTOpython,'X.mat'],'xtopython')
  save ([pathTOpython,'Y.mat'],'ytopython')
 save ([pathTOpython,'W.mat'],'weightstopython')


if Nline == 1; L = LsingleLine;end
Lstart = L(1);
Lstop = L(end);
LineStep = 1;

fprintf('used lines : %d to %d \n',L(1),L(end))

%save file 
if Nline == 1
    %save file with all the spots on 1 line
    SpotList = SpotListsingleLine;
    savefilename = 'spotlist.mat';
    save([fullpath savefilename],'SpotList')
    savefilename = 'spotlistOneLine.mat';
    save([fullpath savefilename],'SpotList')
else
    %save file with spots distributed on multiple lines
    clear SpotList
    SpotList = SpotListAllLines ;
    savefilename = 'spotlist.mat';
    save([fullpath savefilename],'SpotList') ;
    %save file with all the spots on 1 line
    clear SpotList
    SpotList = SpotListsingleLine;
    savefilename = 'spotlistOneLine.mat';
    save([fullpath savefilename],'SpotList');
end

save ('SpotListsingleLine.mat', 'SpotListsingleLine')


%% Pre write output data - definition of stimulation protocol

% here I define the stimualtion parameters 
%%% STIMULATION  PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


calc_sequential_protocol = 0; % 1 to calculate the sequential protocol on each line; %0 to not do it

Tscan = 0.054;%0.05; %0.05% 0.05; %time spent on each line in ms
Tstimtot =30;%100;%10 %total stim time (1 pulse)  30-50 for temperature gcamp
Tinter = 70;%90 for 10hz;  % Dt inter pulses  30-50 for temperature gcamp
Nrep = 10;   % number of pulses 50-100 for temperature gcamp 
NrepSequential = 10;%5; % number of pulses for the sequential mode

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Npower = length(power_per_cell);
AOMpower = mtimes(power_per_cell,CorrPowerV.*PowerCorrDE); 
AOMV = real(power_fun(coeffvals,AOMpower));

% singleLine case
AOMpowersingleLine = mtimes(power_per_cell,CorrPowerV.*PowerCorrDEsingleLine)
AOMVsingleLine = real(power_fun(coeffvals,AOMpowersingleLine));

if max (max([AOMpower]))>710;
    disp('ATTENTION. flit power higher that Pmax available')
end
LinePowerV=AOMV;
LinePowerVsingleLine=AOMVsingleLine;
Noperation = (Lstop-Lstart+1)/LineStep;
Noutinit = 0;%5; % few zeros to add before and after the command
Noutend = 0;%5;

Tstimperline = Tstimtot/Nline; 
TcycleSwitch = (2*Nline) * Tscan;
NcycleSwitch = round(Tstimtot/TcycleSwitch);
TcycleStatic = Tscan;
NcycleStatic = round(Tstimtot/TcycleStatic);
if Nline==1;  Tcycle=TcycleStatic;Ncycle=NcycleStatic;  end

deltaT = Tscan*10^-3*rate;
if deltaT <2 % daq sampling rate must be at least twice the asked frequency 
    rate = 2*1/Tscan/10^-3;
end

% write the command for 1cycle
if Nline == 1
    line1cycleSwitch = LineTOuse;
    line1cycleStatic = LineTOuse;
else
    line1cycleSwitch = [Lstart:LineStep:Lstop Lstop:-LineStep:Lstart];
    line1cycleStatic = LineTOuse;
end
out1cycleSwitch = repmat(LineGalvV(line1cycleSwitch),[deltaT 1]);
out1cycleStatic = repmat(LineGalvV(line1cycleStatic),[deltaT 1]);

% rep for Ncycle
out1stimSwitch = repmat(out1cycleSwitch(:),[NcycleSwitch 1]);
out1stimStatic = repmat(out1cycleStatic(:),[NcycleStatic 1]);

% write for 1rep : stim + delay before next repetition
out1delay = zeros(round(Tinter*10^-3*rate),1);
out1repSwitch = [out1stimSwitch;out1delay];
out1repStatic = [out1stimStatic;out1delay];
% repeat fir Nrep
out1Switch = repmat(out1repSwitch,[Nrep 1]);
out1Static = repmat(out1repStatic,[Nrep 1]);
% add a few zeros before and after command
out1Switch = [zeros(1,Noutinit) out1Switch' zeros(1,Noutend)];
out1Static = [zeros(1,Noutinit) out1Static' zeros(1,Noutend)];
out1singleLine = out1Static;

% same for writing output2
if Npower == 1
    out2cycleSwitch = repmat(LinePowerV(line1cycleSwitch),[deltaT 1]);
    out2stimSwitch = repmat(out2cycleSwitch(:),[NcycleSwitch 1]);
    out2delay = zeros(round(Tinter*10^-3*rate),1);
    out2repSwitch = [out2stimSwitch;out2delay];
    out2Switch = repmat(out2repSwitch,[Nrep 1]);
    out2Switch = [zeros(1,Noutinit) out2Switch' zeros(1,Noutend)];
    
    out2cycleStatic = repmat(LinePowerV(line1cycleStatic),[deltaT 1]);
    out2stimStatic = repmat(out2cycleStatic(:),[NcycleStatic 1]);
    out2repStatic = [out2stimStatic;out2delay];
    out2Static = repmat(out2repStatic,[Nrep 1]);
    out2Static = [zeros(1,Noutinit) out2Static' zeros(1,Noutend)];
     
    outputSwitch = [out1Switch;out2Switch];
    outputStatic = [out1Static;out2Static];
    
    out2cyclesingleLine = repmat(LinePowerVsingleLine(line1cycleStatic),[deltaT 1]);
    out2stimsingleLine = repmat(out2cyclesingleLine(:),[NcycleStatic 1]);
    out2delaysingleLine = zeros(round(Tinter*10^-3*rate),1);
    out2repsingleLine = [out2stimsingleLine;out2delaysingleLine];
    out2singleLine = repmat(out2repsingleLine,[Nrep 1]);
    out2singleLine = [zeros(1,Noutinit) out2singleLine' zeros(1,Noutend)];
    
    outputsingleLine = [out1singleLine;out2singleLine];
    
else

    clear outfinal2Static outfinal2Switch outfinal2singleLine
    for j = 1:Npower
        out2cyclesingleLine = repmat(LinePowerVsingleLine(j,line1cycleStatic),[deltaT 1]);
        out2stimsingleLine = repmat(out2cyclesingleLine(:),[NcycleStatic 1]);
        out2delaysingleLine = zeros(Tinter*10^-3*rate,1);
        out2repsingleLine = [out2stimsingleLine;out2delaysingleLine];
        out2singleLine = repmat(out2repsingleLine,[Nrep 1]);
        out2singleLine = [zeros(1,Noutinit) out2singleLine' zeros(1,Noutend)];
        outfinal2singleLine(j,:) = out2singleLine;
        
        out2cycleStatic = repmat(LinePowerV(j,line1cycleStatic),[deltaT 1]);
        out2stimStatic = repmat(out2cycleStatic(:),[NcycleStatic 1]);
        out2delay = zeros(Tinter*10^-3*rate,1);
        out2repStatic = [out2stimStatic;out2delay];
        out2Static = repmat(out2repStatic,[Nrep 1]);
        out2Static = [zeros(1,Noutinit) out2Static' zeros(1,Noutend)];
        outfinal2Static(j,:) = out2Static;
        
        out2cycleSwitch = repmat(LinePowerV(j,line1cycleSwitch),[deltaT 1]);
        out2stimSwitch = repmat(out2cycleSwitch(:),[NcycleSwitch 1]);
        out2repSwitch = [out2stimSwitch;out2delay];
        out2Switch = repmat(out2repSwitch,[Nrep 1]);
        out2Switch = [zeros(1,Noutinit) out2Switch' zeros(1,Noutend)];
        outfinal2Switch(j,:) = out2Switch;
        
    end
    outputSwitch = permute(cat(3,repmat(out1Switch,[Npower 1]),outfinal2Switch),[3 2 1]);
    outputStatic = permute(cat(3,repmat(out1Static,[Npower 1]),outfinal2Static),[3 2 1]);
    outputsingleLine = permute(cat(3,repmat(out1singleLine,[Npower 1]),outfinal2singleLine),[3 2 1]);
end

%%%% generate figure representing 
tSwitch = (1:1:length(out1Switch))/rate;
tStatic = (1:1:length(out1Static))/rate;
tstimSwitch = (1:1:length(out1stimSwitch))/rate;
tstimStatic = (1:1:length(out1stimStatic))/rate;

figure;
subplot(2,2,1);hold on
plot(tSwitch,out1Switch)
plot(tStatic,out1Static)
plot(tStatic,out1singleLine,'--')
xlabel('time (s)');ylabel('out1 V-galvo')
title('full stimulation')

subplot(2,2,2);hold on
plot(tSwitch,out2Switch)
plot(tStatic,out2Static)
plot(tStatic,out2singleLine)
xlabel('time (s)');ylabel('out2 V- AOM')
limy = ylim;

subplot(2,2,3);hold on
plot(tstimSwitch,out1stimSwitch)
plot(tstimStatic,out1stimStatic)
plot(tstimStatic,out1stimStatic,'--')
xlabel('time (ms)');ylabel('out1 V- galvo')
title('single stim. pulse')

subplot(2,2,4);hold on;
plot(tstimSwitch,out2stimSwitch)
plot(tstimStatic,out2stimStatic)
plot(tstimStatic,out2stimsingleLine)
xlabel('time (ms)');ylabel('out2 V- AOM')
ylim(limy)
legend({'FastSwitch','StaticHolo','AllSpotsOn1Line'},'Location','SouthWest')

%%%% CALC SEQUENTIAL HOLO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if calc_sequential_protocol
    if Nline == 1
        outputSequential = outputsingleLine;
    else
%         out1Sequential = zeros(Nline,length(out1Static));
%         out2Sequential = zeros(Nline,length(out2Static));
clear out1Sequential out2Sequential   
        for i = 1:Nline
            line1cycleSeq = Lstart + i - 1;
            
            out1cycleSeq = repmat(LineGalvV(line1cycleSeq),[deltaT 1]);
            out1stimSeq = repmat(out1cycleSeq(:),[NcycleStatic 1]);
            out1delay = zeros(Tinter*10^-3*rate,1);
            out1repSeq = [out1stimSeq;out1delay];
            out1Seq = repmat(out1repSeq,[NrepSequential 1]);
            out1Seq = [zeros(1,Noutinit) out1Seq' zeros(1,Noutend)];
            
            out2cycleSeq= repmat(LinePowerV(1,line1cycleSeq),[deltaT 1]);
            out2stimSeq = repmat(out2cycleSeq(:),[NcycleStatic 1]);
            out2repSeq = [out2stimSeq;out2delay];
            out2Seq = repmat(out2repSeq,[NrepSequential 1]);
            out2Seq = [zeros(1,Noutinit) out2Seq' zeros(1,Noutend)];
            
            out1Sequential(i,:) = out1Seq;
            out2Sequential(i,:) = out2Seq;
        end
    end
    
    tSeq = (1:1:length(out1Seq))./rate;
    figure;
    title('Sequential mode')
    subplot(1,2,1)
    hold on
    for i = 1:Nline
        plot(tSeq,squeeze(out1Sequential(i,:)));
    end
    xlabel('time (s)');ylabel('out1 V-galvo')
    
    subplot(1,2,2)
    hold on
    for i = 1:Nline
        plot(tSeq,squeeze(out2Sequential(i,:)));
    end
    xlabel('time (s)');ylabel('out2 V- AOM')
    
end


%% start recording

% select mode 
        protocolmode =2 % 0 for Fast Switch btw ALL lines;  FLIT                        
                          % 1 for holographic static illumination of a single line  
                          % 2 for static illumination of a single line containing All spots
                          % 3 for sequential repeat of the protocol on each line                        
                         
        increasePower =1; %1 for increasing power with each stim; 0 for using the same power 
  Nstim=3 % number of stimulation event 
     
      % define rate of samplig for the acquistion card (rate is define already in EXPcalib script)  
        d.Rate = rate;
    
        % trigger imaging TimageBaseline second before starting the stimulation protocol 
TimageBaseline= 10;  % baseline at the beginning of acquisition (sec)
TbetweenStim=20; % (sec)
TbetweenSeq= 5;  %sec
trigMODE=1;   %  1 for trigger at the start of the full rpotocol - STANDARD -(typically trigge rfo the imaging)
              % 2 for trigger for each stimulation event (trigger for each ephys sweep) 
              
writeDigitalPin(ardUno,'D10',0);
pause(0.2)
    if (trigMODE==1); 
    writeDigitalPin(ardUno,'D10',1);  % trig ON for the imaging 
    end 
    
    pause(TimageBaseline);

if increasePower
    for i = 1:Nstim
        if (trigMODE==2); writeDigitalPin(ardUno,'D10',1); end % trig ON  
        if protocolmode == 0
            write(d,squeeze(outputSwitch(:,:,i))');            
        elseif protocolmode == 1
            write(d,squeeze(outputStatic(:,:,i))');
        elseif protocolmode == 2
            write(d,squeeze(outputsingleLine(:,:,i))');
        elseif protocolmode == 3
            disp("Sequential Protocol incompatible with Increase Power mode")
        end
        pause(TbetweenStim)
        if (trigMODE==2); writeDigitalPin(ardUno,'D10',0); end % trig ON  
    end
else
    if protocolmode < 3
        for i=1:Nstim
            if protocolmode == 0
                write(d,squeeze(outputSwitch(:,:,1))');
            elseif protocolmode == 1
                write(d,squeeze(outputStatic(:,:,1))');
            elseif protocolmode == 2
                write(d,squeeze(outputsingleLine(:,:,1))');
            end
            pause(TbetweenStim)
        end
        
    elseif protocolmode == 3
        for j = 1:size(out1Sequential,1)
            write(d,[squeeze(out1Sequential(j,:));squeeze(out2Sequential(j,:))]')
             pause(TbetweenSeq)
        end
        
    end
end
writeDigitalPin(ardUno,'D10',0); % reset Arduino trigger Pin to LOW  
