function [powers,corr_spot_diameters,weights] = power_corr2(power_per_cell,patterns,blobpos,X,Y,V,stim_coeffvals)
% this function compute the proper weigth of each to be corrected for
% diffraction efficiency 

    corr_spot_diameters=0;
    for i=1:size(patterns,1) %for each pattern
        if iscell(patterns)
            de_s = interp2(X,Y,V,blobpos(patterns{i},1),blobpos(patterns{i},2),'cubic');
        else
            for s=1:size(patterns(i,:),2) 
                if abs(blobpos(patterns(i,s),1))>max(X(:));  blobpos(patterns(i,s),1)=max(X(:))*1*sign(blobpos(patterns(i,s),1));
                disp('warning: some ROIs are outside the power calibrated region.');
                end
                if abs(blobpos(patterns(i,s),2))>max(Y(:));  blobpos(patterns(i,s),2)=max(Y(:))*1*sign(blobpos(patterns(i,s),2));
                disp('warning: some ROIs are outside the power calibrated region.');
                end
            end
            de_s = interp2(X,Y,V,blobpos(patterns(i,:),1),blobpos(patterns(i,:),2),'cubic');
        end
        
        powers(i) = power_per_cell * sum(1./de_s);        
        if iscell(patterns)
            weights{i} = power_per_cell ./ de_s;
            weights{i} = weights{i} ./ max(weights{i}) * 0.9999;
        else
            weights(i,:) = power_per_cell ./ de_s;
            weights(i,:) = weights(i,:) ./ max(weights(i,:)) * 0.9999;
        end
    end
    
    if length(stim_coeffvals) ~= 0
        for i=1:size(patterns,1)
            power_corr_spot = max(powers) - powers(i);
            if power_corr_spot < 0
                disp('error: not enough total power')
                power_corr_spot = 0;
            end
            if iscell(weights)
                corr_spot_area = cell_area * (sum(weights{i})/max(weights{i})) *(power_corr_spot/powers(i));
            else
                corr_spot_area = cell_area * (sum(weights(i,:))/max(weights(i,:))) *(power_corr_spot/powers(i));
            end
            corr_spot_diameters(i) = sqrt(corr_spot_area / pi) * 2;
            if corr_spot_diameters(i)/diameter > 3
                disp('corr spot size is > 3 times of a cell')
            end
        end
    end