function [X,Y,X0,Y0]=grid_random_offset(nx, ny, dx, dy, offset)
    x_vec=([1:nx]-(nx+1)/2)*dx;
    y_vec=([1:ny]-(ny+1)/2)*dy;
    [X0,Y0] = meshgrid(x_vec,y_vec);
    X=X0+randi([-dx,dx],ny,nx)*offset;
    Y=Y0+randi([-dy,dy],ny,nx)*offset;