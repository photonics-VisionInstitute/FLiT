%% script for initialize device anc defien main system parameters and implemnt the required calbiration (includign power control, single tile hologram efficiency etc. ) 

%% Configurate NI daq adn Arduino 

d = daq("ni");
addoutput(d, "Dev7", "ao0", "Voltage");
addoutput(d, "Dev7", "ao1", "Voltage");

clear ardUno
disp('Opening Arduino for electrophy triggering...')
ardUno = arduino('COM45'); 
configurePin(ardUno,'D10','DigitalOutput');
writeDigitalPin(ardUno,'D10',0);

%% SLM parameters 
NlineonSLM=45; 

%% AOM calibration laser power-
% I define laser power/versus AOM Voltage depndence and fit it 
calibAOM = [0,0.5,1,1.5,2,2.4,2.7,2.75,2.85,2.9,3,3.1,3.2,3.3,3.4,3.6,3.8,4,4.2,4.4,4.6,4.8,5,5.4,5.7, 6, 6.4, 6.8, 7.2, 7.6, 8, 8.4,8.8, 9.5;...
   0,0,0,0,1,4,13,16,23,27,38,50,65,82,103,154,218,300,393,502,627,765,918,1250,1520,1790,2140,2460,2730,2940,3090,3180,3230,3248];
calibAOM(2,:)=calibAOM(2,:)*1050/3248; % 

x = calibAOM(1,:);
y = calibAOM(2,:);

power_fun =  @(coeff, x)  ( ((-log(1-(x-coeff(4))/coeff(1))).^(1/coeff(5)))*coeff(3)+coeff(2) );

x0=[-3221.53303311144,9.94648654271492,-3.81300273251089,3221.51004476745,0.5];

coeffvals=lsqcurvefit(power_fun,x0,y(5:end),x(5:end));

figure;plot(x,y,'x')
hold on
plot(power_fun(coeffvals,y),y)
xlabel('Voltage (mV)')
ylabel('Power (mW)')

%% Define Voltage and efficiency of each line on the SLM
% I measure for each line the corresponding geenrate fluorescence and
% find the correction  in  laser power  to compensate  losses in the most peripheral lines 

LineGalvV =[ NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, NaN, 169, 156.5, 144,  131.75,   119.5, 107, 94.5, 81.7, 68.9 , 55.95, 43, 30.5, 18, 5.4, -7.2, -19.6, -32, -45, -58, -70.5, -83, -95.75, -108.5, -121.25, -134, -146.25, -158.5, -171.25, -184, -196.5, -209, ]/1000-0.002;

powerLine = [1142	1142	1142	1142	1142	1142	1142	1142	1142	1142	1129	1330	1406	1454	1490	1519	1543	1571	1594	1612	1628	1635	1642	1650	1657	1651	1644	1639	1634	1626	1618	1593	1564	1546	1526	1500	1469	1395	1212	1217	1217	1217	1217	1217	1217]-1050

idx = 1:1:NlineonSLM;
xline = 1:1:NlineonSLM;

figure;
yyaxis left
plot(xline(idx),LineGalvV(idx),'x')
xlabel('line #'); ylabel('galv cmd (V)');xlim([1 NlineonSLM])
yyaxis right
plot(xline(idx),powerLine(idx),'x')
xlabel('line #');ylabel('intensity');xlim([1 NlineonSLM])

LinePowerV = 1*ones(size(LineGalvV));

CorrPowerV =sqrt(1./(powerLine/max(powerLine)));
 figure;yyaxis left;plot(CorrPowerV,'HandleVisibility','off');ylabel('correction factor');yyaxis right;hold on;plot(powerLine);ylabel('intensity')

%%  calibration for extraction of line intensities 
% here i generate single spots  across all the lines to investigate their efficiency
nNlineCalib=45;
clear SpotListCalib
SpotListCalib(1,:)=[1:2:nNlineCalib];
for i=numel(SpotListCalib(1,:))
    SpotListCalib(2,:)=20;
    SpotListCalib(3,:)=-20;
    SpotListCalib(4,:)=0;
    SpotListCalib(5,:)=0.99;
end
SpotList = SpotListCalib;
savefilename = 'spotlist.mat';
save([fullpath savefilename],'SpotList')

%% Calibration /alignement section 1 : statically place galvo on a given Line sending the correspondign voltage
lineIND=25
galvoV=LineGalvV(lineIND);
aomV=2.85; % V
write(d,[galvoV,aomV]);

%%
%% generate spot on a grid 
[Xtnew,Ytnew,Xt0new,Yt0new] =  grid_random_offset(4,4,65,65,0.15);  % 16 spot 

r=[1:1:numel(Xtnew(:))];
mat=[Xtnew(r)',Ytnew(r)'];
blobpos=mat+[20,-15]; %shift 
blobpos=mat+[0,0]; %shift 
N = size(mat,1);  
figure;
for i=1:N
    scatter( blobpos(i,1),blobpos(i,2))
    text(blobpos(i,1),blobpos(i,2) ,num2str(i))
    hold on
end
title([ 'sequence of ' , num2str(N) ' spot'])

%% DE correction
%create the calibration grid used for extraning postion depndent spot
%intensity due to diffraction effciency

[Xt,Yt,Xt0,Yt0] =  grid_random_offset(6,6,70,70,0.05);  

lines = 25; % number of lines to characterize
Ndistrib = 5;

spotlist = distrib_line_random(Xt,Yt,lines);
spotlist3D = zeros([size(spotlist) Ndistrib]);
Z = zeros(1,size(spotlist,2));
W = 100*ones(1,size(spotlist,2));
for i =1:Ndistrib
    spotlist = distrib_line_random(Xt,Yt,lines);
    % save spot list
    SpotList = [spotlist;Z;W];
    filename = ['spotlistcalib' num2str(i) '.mat'];
    save([folder_path filename],'SpotList')
    spotlist3D(:,:,i) = spotlist;
end

%% calibration of Diffraction efficiency
% here I consider a grid of spots, and insert the measure itnesnity of each
% % spot to build the diffraction efficiency spatial profile 
step=80;  % grid step

[Xt,Yt,Xt0,Yt0] =  grid_random_offset(6,6,step,step,0.05);  

%grid275 is the matric of the fluorescent intensities of each spot in the %grid 
% in this specific case the spot order is from bottom left corner going up adn right  along the grid 
grid275 = [553, 936,1079,1082,593,400; 634,1187,1308,1532,1125,475;906,1089,1500,1320,708,643;984,1533,1176,1377,880,545;851,1507,1439,1456,929,446;495,816,993,936,530,400];

grid275 = grid275./max(grid275(:));

V = grid275;
V = sqrt(V);
V = flipud((V));

figure;
imagesc(grid275)
colorbar
c = caxis;
title(['std = ' num2str(std(grid275(:)),3)])

