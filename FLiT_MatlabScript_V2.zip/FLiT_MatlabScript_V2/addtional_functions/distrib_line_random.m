function spotlist = distrib_line_random(Xt,Yt,lines)
    % distribute the spots randomly between the lines 
    Nspots = length(Xt(:));
    Nlines = length(lines);
    if rem(Nspots,Nlines) ~= 0
        disp("Nspots non divisible by Nlines")
        return
    end
    
    X = Xt(:);
    Y = Yt(:);
    
    xstretch=0.975;
    ystretch=1.035;
    theta=2/180*pi; %°
    xOFFSET=0;
    yOFFSET=-2;
    
    % XY
    X = X*xstretch;
    Y = Y*ystretch;
    X=X*cos(theta)-Y*sin(theta)+xOFFSET;
    Y=X*sin(theta)+Y*cos(theta)+yOFFSET;

    
    
    L0 = repmat(lines,[Nspots/Nlines 1]);
    L0 = L0(:);   

    idx = randperm(size(L0(:),1));
    L = L0(idx);

    spotlist = cat(2,L,X,Y)';
end